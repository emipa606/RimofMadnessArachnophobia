﻿using Verse;

namespace Arachnophobia
{
    [StaticConstructorOnStartup]
    public static class ModInfo
    {
        public static float romSpiderFactor = 1;
    }
}
